# Scrapnel
a top down, fallout like, wasteland shooter by an idiot who doesn't know python, (Training Exercise)
