import time
import random
import turtle
#import threading
import sys
#import colored
import math
import pygame

import pygame, sys
from pygame.locals import QUIT

pygame.init()
screen = pygame.display.set_mode((886,886))
pygame.display.set_caption('Scrapnel')
icon = pygame.image.load("download4.png")

pygame.display.set_icon(icon)
#pygame.display.set_caption('Hello World!')
clock = pygame.time.Clock()
basicdirtimg =  pygame.image.load("bestdirt1.jpg")
basicdirt = pygame.Surface((886,886))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit
            exit()
    pygame.display.update()
    clock.tick(20)
    